# Chapter 7B — Mapping the Mouth

## §7B.1 — Mapping the Mouth

American schoolchildren are taught "phonics" to navigate the structural chaos of the Roman alphabet — a patchwork of rules and exceptions imposed on a script that struggles to encode pronunciation. The cluster *ough* changes acoustic value across *tough*, *though*, and *through*. *C* says /k/ in *cat* and /s/ in *city*. *Gh* says /ɡ/ in *ghost*, /f/ in *laugh*, and nothing at all in *though*. English spelling is not a map of sound; it is an archaeological site. Every word preserves older layers — Latin, French, Germanic, scribal habit, imperial standardization — so the child is not simply reading pronunciation, but excavating it.

Children learning Indian languages don't need phonics. The Devanagari letter क says क. ख says ख. ग says ग. The letter and the sound it names are the same thing. There is no drift to bridge, no exception list to memorize, no rule about when *c* becomes *s*. The script *is* the phonetic specification.

Indian children learning English do not learn phonics the way English-monolingual children do. They internally map Roman letters onto the phonic Indic script they already operate. *Cat* reads as क-ऍ-ट. The Roman string is the foreign notation; the Indic phonemes are the native categories. The child does not bridge a script-sound drift; the child translates between two scripts, one of which carries the phonetics implicitly.

The reason the Indic scripts can do this is that they were engineered alongside the phonological specification they represent. The script is not a historical accumulation of letters that drift from sounds. The script is a direct visual encoding of an engineered specification of the human mouth as a phonetic instrument. The previous chapter mapped that instrument. This chapter takes up the inventory and the encoding.

---

## §7B.2 — The Selection

The previous chapter described the human vocal apparatus and the framework Sanskrit developed to classify what it produces — *sthāna* for place of articulation, *prayatna* for effort, *prāṇa* for breath pressure, *ghoṣa* for vocal-cord vibration, *anunāsika* for nasal coupling. The framework is general; it describes the apparatus. What the framework specifies is universal — every human vocal tract has the same anatomy and operates the same parameters.

What one specific language commits to is a different question. Out of the vast space of sounds the apparatus could produce, every language selects a finite inventory. This chapter takes up the Sanskrit selection.

Sanskrit's name for a phonological unit is *varṇa* वर्ण — literally "color, character, class" — the sound considered as a structural unit of the phonological system. The full inventory of *varṇas* is the *varṇamālā* वर्णमाला — the "garland of sounds." The *mālā* (garland) is a deliberate metaphor: the *varṇas* are strung in a definite sequence on a thread, the sequence is not arbitrary, and the order in which they appear encodes their relationships to each other. The Sanskrit *varṇamālā* is not an alphabet in the European sense. It is a structured inventory presented in an order that is itself information about the sounds.

The inventory has four divisions.

**Twenty-five *sparśa* consonants** — the contact sounds, organized in a 5×5 grid. Five rows: one row per *sthāna*. Five columns: one column per combination of voicing, aspiration, and nasal coupling. Each row is called a *varga* वर्ग (class). The five *vargas* are named by their leading consonant: *kavarga* (क ख ग घ ङ), *cavarga* (च छ ज झ ञ), *ṭavarga* (ट ठ ड ढ ण), *tavarga* (त थ द ध न), *pavarga* (प फ ब भ म). Each *varga* anchors at one of the five *sthāna* — velar, palatal, retroflex, dental, labial respectively — and contains the five within-row positions that the *bāhya prayatna* dimensions produce.

**Fourteen *swaras*** — the vowels, presented as five base positions with engineered temporal cuts. The base positions are अ, इ, उ, ऋ, ऌ. Each base position pairs with a long counterpart (आ, ई, ऊ, ॠ, no long ऌ in operation), and four diphthongs (ए, ऐ, ओ, औ) complete the system. Five base swaras × temporal cuts + diphthongs = fourteen *swaras*.

**Four *antaḥstha*** — the semivowels य, र, ल, व. The *in-between* sounds: each placed at one of the *sthāna* positions, each operating the light-contact mode that bridges the open-airflow of *swara* and the full-contact mode of *sparśa*.

**Four *ūṣman*** — the fricatives and the aspirate: श, ष, स, ह. The *hot-breath* sounds: air squeezed through a narrow channel at one of the *sthāna* positions, producing the characteristic turbulence the term names.

Twenty-five plus fourteen plus four plus four. Forty-seven *varṇas* in the core inventory. Two further markers — anusvara (ं) for nasal echo and visarga (ः) for a glottal aspirate — round out the operational set. The inventory is finite, ordered, and exhaustive of the sound-space the language commits to.

Each *varṇa* in the inventory is a sound — and the same *varṇa* is also the name of that sound. The Devanagari letter क is the visual form, /kə/ is the phonetic value, *ka* is the transliteration, *kakāra* is what Sanskrit calls the consonant when it needs to be referred to by name. All four point to the same thing: a *sparśa* sound at the *kaṇṭhya sthāna* with *aghoṣa* voicing, *alpaprāṇa* breath pressure, no nasal coupling. The grid position determines the sound; the sound is what the grid position commits to. There is no slippage between the inventory's name for a sound and the sound itself.

The names of the sounds happen to be the sounds themselves.

---

## §7B.3 — Snap to the Grid

Illustrators know snap-to-grid. Drag an anchor point in Adobe Illustrator, in Figma, in Blender, in any 3D modeler — as the cursor nears a grid intersection, it jumps the last few pixels and locks. The grid is the destination. The cursor is what snaps. The function exists because precision matters and the human hand cannot place a point exactly without help.

Sanskrit's *varṇamālā* operates the same way. The mouth can place the tongue at many positions along its arc — far more than five. The grid is the specification of which positions to use. The sounds chosen for Sanskrit snap to the grid located in the mouth.

The *sparśa* grid samples five points along the vocal tract, measured from the lips backward: approximately 0 cm (labial — *pavarga*), 3 cm (dental — *tavarga*), 7 cm (retroflex — *ṭavarga*), 9 cm (palatal — *cavarga*), 12 cm (velar — *kavarga*).[NOTE: varnamala-grid-geometry] The intervals between included positions — approximately 3, 4, 2, 3 cm — are not strictly equidistant. The grid is doing something more sophisticated than equal spacing. It samples five well-separated positions across the front-to-back range, with each pair of adjacent positions separated by at least ~2 cm for clean acoustic distinguishability. The retroflex base at ~7 cm sits structurally central — the midpoint anchor of the five-point sampling.

[FIGURE 7B.1: *Snap to the Grid.* — A linear stretched-out representation of the vocal tract from 0 cm (lips) to ~17 cm (glottis). Sanskrit's five grid positions marked clearly (labial / dental / retroflex / palatal / velar). English consonants plotted at their approximate positions (interdental *th* at ~2 cm; alveolar *t*, *d*, *n*, *s*, *z*, *l*, *r* at ~4–5 cm; post-alveolar *sh*, *ch*, *zh* at ~5–6 cm). Arabic deep-pharyngeal ع and ح plotted at ~15 cm. Arrows show how the English alveolar/post-alveolar sounds snap to either the Sanskrit dental or retroflex position depending on tongue placement; the English interdental excluded by adjacent-exclusion to dental; the Arabic pharyngeal marked as outside the grid's range entirely. The single visual carries the chapter's central engineering argument: the superset of mouth-producible sounds is bigger than the grid; the grid is the chosen subset.]

The English phonological apparatus includes an interdental fricative at approximately 2 cm — the consonants written *th* (θ, ð), produced by placing the tongue tip between or at the front face of the upper teeth. The Sanskrit dental at ~3 cm sits only ~1 cm behind it. The two articulation points are too close for clean acoustic separation. Sanskrit's grid snaps to the dental at 3 cm and excludes the interdental at 2 cm; the dental position wins the snap.

The same pattern governs the entire ~4 cm region between the Sanskrit dental (~3 cm) and the Sanskrit retroflex (~7 cm). The intervening region houses the alveolar (~4 cm), the post-alveolar (~5–6 cm), and the palato-alveolar (~6 cm) positions — the heart of the English consonantal apparatus, where *t*, *d*, *n*, *s*, *z*, *l*, *r*, *sh*, *ch*, and *j* all live. Sanskrit's grid crosses this entire region in a single step. The five *vargas* include no alveolar *varga*, no post-alveolar *varga*, no palato-alveolar *varga*. Sounds the mouth can produce in this region snap to dental at one boundary or retroflex at the other, depending on tongue position — they do not get a row of their own.

The Arabic phonological apparatus includes a deep-pharyngeal articulation at approximately 15 cm — the consonants ع and ح, produced by constricting the throat well behind the velum. The Sanskrit velar at ~12 cm is the back-end of the grid's included range. Positions deeper than the velum are outside the grid entirely. The pharyngeal is physiologically available; the Arabic apparatus uses it without difficulty; Sanskrit's grid does not extend to it. This is range-boundary, not snap — the pharyngeal is not adjacent to anything the grid includes; it is beyond the grid's specified scope.

What the grid leaves out, the mouth can still do. The English interdental, the alveolar region, the Arabic pharyngeal — every one of them is physically producible by a Sanskrit speaker's mouth. The grid is not a constraint on what the mouth can articulate. The grid is a specification of which positions the language uses for clean acoustic separability. The superset of mouth-possible sounds is bigger than the grid. The grid is the chosen subset.

The grid is strict at the syllable and word level. At word boundaries, where adjacent sounds meet, the grid relaxes in governed ways. *Sandhi* rules — the system of phonological transformations Sanskrit applies at boundaries — describe the controlled loosening of the snap. The clearest case is anusvara assimilation. The nasal ṃ at a word's end snaps to the place of articulation of the consonant that follows: ṃ + क → ङ्क; ṃ + च → ञ्च; ṃ + ट → ण्ट; ṃ + त → न्त; ṃ + प → म्प. The nasal does not stay at one fixed position; it relocates to match the following consonant's row.[NOTE: sandhi-anusvara-assimilation] The grid snaps. The snap is strict. *Sandhi* is the governed loosening. All three are engineered.

---

## §7B.4 — The Naming of the Sounds

The previous chapter introduced the five *sthāna* — *oṣṭhya*, *dantya*, *mūrdhanya*, *tālavya*, *kaṇṭhya* — and showed the consistent derivational pattern that names each anatomical contact-station as an adjective derived from the body part where contact happens. The *varṇamālā* layers a second naming system on top of the anatomical one. Each of the five rows is named by its leading consonant. The row anchored at *oṣṭhya* is the *pavarga* (the row of प). The row anchored at *dantya* is the *tavarga* (the row of त). The row anchored at *mūrdhanya* is the *ṭavarga* (the row of ट). The row anchored at *tālavya* is the *cavarga* (the row of च). The row anchored at *kaṇṭhya* is the *kavarga* (the row of क).

Two parallel naming conventions for the same five rows: one anatomical (where the sound is articulated), one structural (which consonant heads the row). The reader of Sanskrit grammar has both at her disposal; either system points unambiguously to the same row. The redundancy is itself a piece of engineering — the same five rows are addressable two ways, and the two ways cross-reference each other to lock the structure in place.

The within-row positions are also named systematically. Each *sparśa* consonant is identified by a parameter string that combines its *sthāna* with its *bāhya prayatna* modifiers. क is *aghoṣa-alpaprāṇa-kaṇṭhya*. ख is *aghoṣa-mahāprāṇa-kaṇṭhya*. ग is *ghoṣa-alpaprāṇa-kaṇṭhya*. घ is *ghoṣa-mahāprāṇa-kaṇṭhya*. ङ is *ghoṣa-anunāsika-kaṇṭhya*. The five names of the five consonants in *kavarga* are not arbitrary labels; they are the parameter strings that specify how each sound is to be made. The same pattern operates across all five rows. The naming system encodes the production specification.

This is the deeper meaning of the observation that closed §7B.2: the names of the sounds happen to be the sounds themselves. The Devanagari letter क does not name a sound by convention; it names the sound by encoding the production specification — *aghoṣa-alpaprāṇa-kaṇṭhya*. The same character functions as visual form, phonetic value, and parameter string. There is no slippage between any of these layers.

---

## §7B.5 — The Engineering Precedes Pāṇini

The terms developed in this chapter and the previous one — *sthāna*, *karaṇa*, *prayatna*, *prāṇa*, *ghoṣa*, *anunāsika*, *sparśa*, *swara*, *antaḥstha*, *ūṣman*, *spṛṣṭa*, *aspṛṣṭa*, *aghoṣa*, *alpaprāṇa*, *mahāprāṇa*, *anupradāna*, *vivṛta*, *saṃvṛta*, *varga*, *varṇa*, *varṇamālā* — are not modern coinages. They are documented in the *Prātiśākhya* tradition (Ṛk-, Taittirīya-, Vājasaneyī-, Atharva-Prātiśākhya) and the *Śikṣā* texts of the *Vedāṅga* (*Pāṇinīya Śikṣā*, *Yājñavalkya Śikṣā*, *Āpiśali Śikṣā*, and the related treatises).[NOTE: pre-panini-pratisakhya-classification] These are the texts that document the *varṇamālā*'s structure: the five *sthāna*, the *karaṇa* of each, the *ābhyantara prayatna* categories (*spṛṣṭa*, *īṣat-spṛṣṭa*, *īṣat-saṃvṛta*, *vivṛta*) that determine manner of articulation, the *bāhya prayatna* dimensions (voicing, aspiration, nasal coupling) that determine the within-row positions, the 5×5 *varga* matrix, the *antaḥstha* and *ūṣman* categories.[NOTE: place-of-articulation-sanskrit-terms]

The conventional account of how this framework came to exist invokes *centuries of analysis*. The *Prātiśākhya* tradition, on this telling, accumulated observations across many generations until the multi-axis classification emerged as the residue of that accumulation. The phonological concepts were *discovered and defined* in the course of textual development. The framework is the convergent result of a research program.

This account misreads what the *Prātiśākhya* texts do. The texts preserve and transmit. They do not construct. The classification framework was already part of Sanskrit's architecture; the *Prātiśākhya* tradition carried it forward across many generations of *guru-shishya* transmission. The framework's depth is the depth of the language it describes — not the depth of an empirical inquiry that produced it. The *Prātiśākhya* tradition did not invent this framework. It carried forward what was already part of Sanskrit's architecture.

This distinction matters. Frits Staal's classical observation deserves close attention here. Staal noted that the *varga* system shares a logic with Mendeleev's periodic table — both systems place units at unique coordinates determined by their constituent components.[NOTE: staal-mendeleev-varga-comparison] The structural comparison is correct. The *varga* grid does decompose every *sparśa* sound into the unique combination of *sthāna* + *karaṇa* + *ābhyantara prayatna* + *bāhya prayatna* that produces it; the periodic table does the same thing for atoms. The architecture of the *varga* system mirrors the architecture of chemistry's reference system at the level of how units are placed in the system. That parallel is genuine, and the next section presents the grid through visualizations that make the parallel visible.

But Staal extended the comparison further. He claimed that the *varga* system, like the periodic table, *was the result of centuries of analysis*. The *basic concepts of phonology*, he wrote, *were discovered and defined* in the course of that development. The historical claim does not follow from the structural comparison. Mendeleev's periodic table was assembled by chemists working empirically over decades of laboratory inquiry. The *varga* grid was not assembled empirically; it was carried forward as part of Sanskrit's existing architecture. The structural parallel is real. The historical parallel is not. The texts preserve and transmit; they do not construct.[NOTE: architecture-not-analysis-pratisakhya]

The engineering precedes Pāṇini.

Pāṇini was second.

His *Aṣṭādhyāyī* operates the *varṇamālā* terminology as already-established vocabulary. Pāṇini does not introduce *sthāna*; he uses it. He does not introduce *prayatna*, *karaṇa*, *anupradāna*, *spṛṣṭa*, *vivṛta*, *saṃvṛta*, *aghoṣa*, *ghoṣa*, *alpaprāṇa*, *mahāprāṇa*, the 5×5 *varga* matrix, or the *antaḥstha* / *ūṣman* categories. He uses all of them, as already-operating vocabulary, in the construction of his analytical rule-system. The *Śiva Sūtras* that open the *Aṣṭādhyāyī* reorder the *varṇamālā*'s sound-set for the analytical engine Pāṇini was building, and a reordering presupposes a prior ordering. What Pāṇini built was the engine. What Pāṇini built on was the platform. The platform was the *varṇamālā*; the platform was already engineered.

The Western philological encounter with Sanskrit grammar focused on the *Aṣṭādhyāyī*, and Pāṇini became the named figure — the genius of Sanskrit grammar, the founder of generative linguistics, the architect of the analytical mode. The pedestal grew so high that the engineering Pāṇini inherited stands in his shadow. The *Prātiśākhya* tradition is anonymous and distributed across the four Vedas; the *Śikṣā* texts are a *Vedāṅga* auxiliary, not a named-author masterpiece. Neither fits Western philology's focus on named-author analytical works. So the older engineering got tagged *pre-Pāṇinian* and quietly stepped behind Pāṇini in the hierarchy of celebration.

Pāṇini was great. The engineering Pāṇini codified was greater. The establishment narrative collapses the first onto the second and erases the distinction. The terminology has been operating across many generations of *guru-shishya* transmission before any European philological tradition existed to name what it would later name in its own Latin and Greek vocabulary.

The Western linguistic tradition encountered Sanskrit grammar through colonial-era contact and absorbed its framework across the long nineteenth century. Sir William Jones, presiding judge at the Calcutta Supreme Court, delivered his *Third Anniversary Discourse to the Asiatic Society* in 1786, recognizing Sanskrit as related to Greek and Latin and to the Gothic, Celtic, and Persian languages — opening the comparative-philological project the next century built.[NOTE: jones-1786-third-anniversary-discourse] Friedrich Schlegel's *Über die Sprache und Weisheit der Indier* (1808) brought Sanskrit grammatical analysis into German philology. Franz Bopp's *Über das Conjugationssystem der Sanskritsprache* (1816) established the systematic-comparative method that ran through the rest of the nineteenth century. Otto von Böhtlingk produced the first critical edition of Pāṇini's *Aṣṭādhyāyī* in 1839–40, putting Sanskrit grammatical methodology in front of European linguistics in its original form. William Dwight Whitney's *Sanskrit Grammar* (1879) became the standard English-language reference. By the time the International Phonetic Association was founded in Paris in 1886 and the first IPA chart was published in 1888, European phonological science was operating within a framework structurally identical to the *varṇamālā*'s 2D specification — places of articulation organized as rows, manner of articulation organized as columns.[NOTE: ipa-1886-founding-1888-chart]

The English terms — labial, dental, retroflex, palatal, velar — have their own Greek and Latin anatomical etymologies. The etymological roots are independent. But the systematic deployment of these terms as a unified 2D phonological grid follows the Sanskrit framework European linguistics absorbed across the nineteenth century. The Greek and Latin words existed; the engineered structure they came to name was not Greek's, not Latin's, and not European linguistics's. Sanskrit grammar had organized the territory long before European philology arrived to translate it.[NOTE: history-of-linguistics-sanskrit-influence]

The terminology was Sanskrit's. The systematization was Sanskrit's. Europeans did not invent, they translated.

---

## §7B.6 — The Acoustic Engineering

To understand the *varṇamālā*, stop thinking like a linguist. Start thinking like an acoustic engineer. The Western model treats the mouth as a black box that magically outputs abstract sounds. The Indic model deconstructs the human head as a biological wind instrument governed by fluid dynamics and mechanical oscillation.

Speech is the coordinated operation of four anatomical systems. The tongue (with the lips) positions the closure. The lungs supply the breath pressure. The vocal cords vibrate or stay silent. The soft palate routes the airflow through the oral cavity alone, or opens the nasal cavity to it. Four anatomies, four independent variables — and the *varṇamālā* commits one phonological dimension to each. Tongue and lips for *sthāna*. Lungs for *prāṇa*. Vocal cords for *ghoṣa*. Soft palate for *anunāsika*. Each Sanskrit name points to the anatomy it controls. The Western abstract vocabulary — *place*, *aspiration*, *voicing*, *nasality* — does not. *Voicing* does not point to the vocal cords. *Aspiration* does not point to the lungs. *Place* does not point to the tongue. *Nasality* points to the nose but not to the soft-palate routing that produces the dual-chamber coupling. Sanskrit names the systems directly. The vocabulary is anatomical; the dimensions are physiological; the engineering of the grid maps each phonological feature to its anatomical source.

The four-anatomies count is systems, not structures. The place dimension itself fans out across five anatomical structures along the vocal tract — lips, teeth, hard-palate crown, palate, velum — each one a separate passive articulator that the tongue meets, except at the labial position where the lips contact each other and the tongue is not involved. Five for *sthāna*, plus lungs, vocal cords, and soft palate — eight distinct anatomies that the *varṇamālā* commits to and names. The vocabulary is anatomical at every position.

The physics tracks the engineering. The ~17 cm vocal tract — closed at the glottis, open at the lips — supports resonant modes at specific frequencies. The acoustic signature of any vowel is its formants: the first few resonant peaks that the spectrum carries. Tongue height shifts the first formant; tongue front-to-back position shifts the second. The five *sthāna* positions sample the formant space at well-separated acoustic points, just as they sample the vocal tract at well-separated cm-distances. Spatial well-separation produces acoustic well-separation.[NOTE: formants-source-filter-theory] The grid is acoustically engineered, not just spatially organized. The five places of articulation are five distinguishable cavity geometries; the cavity geometries produce five distinguishable formant signatures; the listener's ear discriminates the formant signatures without effort because the engineering selected positions far enough apart in formant space that confusion is unlikely. The nasal coupling adds anti-resonances — spectral notches — that the four oral positions cannot produce, which is why *anunāsika* is a separate dimension and not a variant of one of the other four. The *alpaprāṇa* / *mahāprāṇa* contrast is a pressure differential at the moment of release — the same physics as overblowing a wind instrument, where higher pressure produces a distinct acoustic burst.

The grid is acoustically engineered, not just spatially organized. Five positions; five formant signatures; five anatomically named *sthāna*. The engineering converges on the physics; the vocabulary names the engineering.

---

## §7B.7 — Reading the Varṇamālā

Imagine a grand pipe organ. The Roman alphabet expects the reader to memorize which pedal arbitrarily triggers which pipe. The *varṇamālā* is the engineering schematic of the organ itself. Reading the coordinate घ on the matrix is not the retrieval of an abstract sound. It is the issue of a precise string of neuro-motor commands: maximize the bellows' thermodynamic output (*mahāprāṇa*), engage the oscillator at the base of the tube (*ghoṣa*), strike the actuator against the deepest, furthest anvil (*kaṇṭhya*). The acoustic wave is not arbitrary. It is the structurally inevitable result of those three physical parameters. The *varṇamālā* does not store sounds. It stores the parameter strings that the speaking body executes to produce sounds.

The 25 *sparśa* consonants of the five *vargas* are a 5×5 grid, and the grid can be presented through several complementary visualizations. The grid is one structure, but its operational logic becomes inescapable when seen through different visual idioms. The chapter shows the same grid through three views — each making a different aspect of the engineering visible.

[FIGURE 7B.2: *View 1 — Control Panel.* — The *varṇamālā* as an operational instrument board. Y-axis = *sthāna* (top-to-bottom in recitation sequence: *kaṇṭhya* → *tālavya* → *mūrdhanya* → *dantya* → *oṣṭhya*). X-axis = *prayatna* (left-to-right: *aghoṣa-alpaprāṇa* → *aghoṣa-mahāprāṇa* → *ghoṣa-alpaprāṇa* → *ghoṣa-mahāprāṇa* → *anunāsika*). Each cell carries the Devanagari character and IAST transliteration. Reads as a control panel: down the Y-axis, the *sthāna* moves outward through the mouth from throat to lips; across the X-axis, the *prayatna* modulates the same *sthāna* through breath, vibration, and nasal opening. The figure compresses the *varṇamālā* into an operational diagram. Not an inventory of symbols. An acoustic anatomy.]

The control panel makes the operation of the grid visible. Each cell is a coordinate; each coordinate is a parameter string; each parameter string is the production specification for a sound.

[FIGURE 7B.3: *View 2 — Periodic-Table Style.* — The 25 *sparśa* consonants in a 5×5 grid styled visually like Mendeleev's periodic table. Each consonant in its own bordered cell. Anatomical parameters encoded via cell-color (one color family per *sthāna* row) and corner labels (small superscript notation indicating the *bāhya prayatna* components — voicing, aspiration, nasal coupling). The visualization makes visible what the control panel describes operationally: each consonant is decomposed into its anatomical components and placed at the unique coordinate where those components meet. The structural parallel between the *varga* grid and the periodic table that Staal noted is the structure this view exhibits.]

The periodic-table view makes the decomposition visible. The grid does not just list 25 sounds; it shows each sound as the unique combination of its anatomical components. The structural parallel with chemistry's reference system is not analogical; it is architectural.

[FIGURE 7B.4: *View 3 — Matrix Table.* — Plain rows × columns table — the most data-dense rendering. Each row a *sthāna*; each column a *prayatna* operating mode; each cell carries the Devanagari character, IAST transliteration, and the four-anatomy decomposition (the *sthāna* + the three *bāhya prayatna* parameters). Suitable for reference look-up.]

Three views of the same grid. The reader who has read this chapter sees the structure through each view in turn and ends with the recognition that the grid is not a list of letters. It is an engineered specification of the speaking body. The visual idioms differ; the structure they exhibit is one.

The remaining categories of the *varṇamālā* — the *swaras*, the *antaḥstha*, the *ūṣman* — operate parallel structures. The *swaras* sample the vowel-space at well-separated resonance points, with engineered temporal cuts (*hrasva*, *dīrgha*, *pluta*) layering the time dimension on top of the spatial. The *antaḥstha* sit at four of the five *sthāna* positions, operating the *īṣat-spṛṣṭa* (light contact) mode that bridges *swara* and *sparśa*. The *ūṣman* operate the *īṣat-saṃvṛta* (light closure) mode at the palatal, retroflex, dental, and glottal positions. Each category extends the same engineering across a different operational range. The full *varṇamālā* is the integrated specification of all four categories at once.

---

## §7B.8 — The Subcontinental Substrate

The *mahāprāṇa* dimension is the *varṇamālā*'s engineering elaboration on top of the shared subcontinental phonetic hardware. The *alpaprāṇa* set is subcontinent-wide — every native language group of the subcontinent operates the unaspirated positions. The *mahāprāṇa* doubling — every unaspirated position gets a high-pressure counterpart in the *varga* — is the Sanskrit-specific commitment. Tamil's classical phonology, for instance, does not operate the *mahāprāṇa* contrast at the *varga* level; the *alpaprāṇa* base set is what Tamil shares with Sanskrit, while the *prāṇa* dimension is what Sanskrit's *varṇamālā* engineers further.

Hindi everyday speech includes the retroflex flap ड़ and its aspirated counterpart ढ़ — sounds the speaker uses thousands of times a week without ever thinking of them as retroflex features. *घोड़ा* (*ghoṛā*, horse), *पेड़* (*peṛ*, tree), *लड़का* (*laṛkā*, boy) — all in everyday vocabulary, all running the retroflex flap. *बूढ़ा* (*būḍhā*, old man), *पढ़ना* (*paṛhnā*, to read) — the aspirated flap. These are not separate positions in the grid; they are positional realizations of ड and ढ in intervocalic context. Same retroflex row, same row-position, briefer palatal contact — written with a *nuqta* (the dot beneath the letter) as the script's later notational accommodation that lets writing capture the realization the *varṇamālā*'s grid encodes structurally.

The subcontinent's phonetic landscape is a layered system. The *alpaprāṇa* base is the shared substrate, operated by every language family of the region. The *mahāprāṇa* doubling is Sanskrit's engineering elaboration on top of that substrate. The retroflex *varga* is the contact-station that marks subcontinental phonology as distinct from any other region of the world. The *anunāsika* coupling, the *ūṣman* set, the *swara* temporal cuts — each adds another engineered layer to the substrate the languages share. The *varṇamālā* is the integrated specification of all layers; subcontinental phonologies are the partial implementations that share the substrate and operate different combinations of the engineered layers.

---

## §7B.9 — Two Instruments

The vocal apparatus the previous chapter mapped can be played in two modes. With *sparśa* — contact between the tongue and an anvil, or between the lips themselves — the apparatus produces an event: a stop, a closure, a release. This is the struck-instrument mode. Without *sparśa*, the apparatus produces a continuous flow: the mouth holds a position; the air passes; sound emerges and sustains. This is the wind-instrument mode proper. *Swara* is the wind-instrument mode of the same apparatus that *sparśa* plays as the struck-instrument mode.

A *swara* held forever is a tone; a *swara* cut to a specific duration is a vowel. Sanskrit's vowel system specifies three engineered temporal lengths:

- ***Hrasva*** ह्रस्व (short) — one *mātrā* मात्रा (one beat). The base unit of vowel duration.
- ***Dīrgha*** दीर्घ (long) — two *mātrā*. Exactly twice the duration of *hrasva*.
- ***Pluta*** प्लुत (extended) — three or more *mātrā*. Used in calling-out, in certain Vedic recitational contexts, and in moments where the speaker holds the vowel deliberately. The famous Pāṇinian example is *he Devadatta3* — the *3* notation in some Sanskrit texts marks a *pluta* vowel held for three beats.[NOTE: hrasva-dirgha-pluta-matra]

The *mātrā* is not an approximation. It is an engineered temporal unit, defined as the duration of a single short vowel. *Dīrgha* is exactly two *mātrā* — the same swara, held twice as long. *Pluta* is three or more. The temporal cuts are precise.

The complete vowel system is the 2D specification of five base *swaras* × engineered temporal cuts: अ / आ; इ / ई; उ / ऊ; ऋ / ॠ; ऌ (without operative long counterpart). Plus the diphthongs — engineered glides between two vowel positions: ए, ऐ, ओ, औ. The vowel system is five base *swaras* × engineered temporal cuts + glides between positions. The 2D specification is cleaner than the consonant grid's multidimensional cross-product. Consonants vary in place, manner, voicing, aspiration, nasality — five dimensions. Vowels vary in mouth position and temporal length — two dimensions, with the glides as the third structural case. The vowel matrix is the simplest engineering case in the *varṇamālā*. The simplicity is the proof of design.

The same *swara* that Indian classical music holds for bars and the Vedic mode marks for pitch contour, speech cuts to precise *mātrā*.[NOTE: vedic-svara-system] The unity is structural. Speech is the engineered subset of the continuous *swara* apparatus that music and the Vedic mode operate at fuller temporal range. Two instruments. One apparatus.

The retroflex *varga* — ट ठ ड ढ ण — is the third row of the *varṇamālā*'s consonantal grid. It sits at the structural midpoint of the vocal tract, the anchor position between the front cluster (labial, dental) and the back cluster (palatal, velar). The next chapter isolates this single row and develops it: the retroflex contact-station as the test of *āryatva*, the codification perimeter that Pāṇini's *bhāṣāyām* mode bounded, and the consonants the *Ṛgveda* operates that the codified mode does not. This chapter has presented the full grid; the next chapter takes one row of that grid and shows what it carries.

---

## §7B Close — Roman Inventory, Varṇamālā Anatomy

The Roman alphabet is an inherited visual inventory. The *varṇamālā* is an acoustic anatomy. The alphabet asks one question: what symbol comes next? The *varṇamālā* asks four: where is the sound struck, how forcefully is the breath released, are the vocal cords vibrating, is the nasal chamber opened? The Roman alphabet behaves like an alphabet. The *varṇamālā* behaves like a scientific diagram of the speaking body.

Four systems. Eight anatomies. One engineered structure.

Phonics is a workaround. The *varṇamālā* is the engineering.
